import numpy as np


class Perceptron:
    def __init__(self, input_descriptions: list, learning_rate: float, name: str, weights: list, test_set: list,
                 train_set: list):
        self.input_descriptions = input_descriptions
        self.learning_rate = learning_rate
        self.name = name
        self.weights = weights
        self.test_set = test_set
        self.train_set = train_set

        self.dimension = len(train_set[0].inputs)
        self.weights = weights[1:self.dimension + 1]
        self.bias = weights[0]
        self.train_history = []

    def train(self, epoch_count: int = 100):
        for _ in range(epoch_count):
            total_error = 0
            for train_element in self.train_set:
                predicted_output = np.sign(np.dot(train_element.inputs, self.weights) + self.bias)
                # predicted_output = 1 if np.dot(train_element.inputs, self.weights) > 0 else 0
                error = train_element.output - predicted_output
                total_error += abs(error)
                self.weights = self.weights + train_element.inputs * error * self.learning_rate
                self.bias = self.bias + error * self.learning_rate

            if total_error == 0:
                break

            self.train_history.append([self.bias, *self.weights])

    def test(self) -> dict:
        result = []
        for train_element in self.test_set:
            predict = np.sign(np.dot(train_element.inputs, self.weights) + self.bias)
            result.append(predict)
        return result
