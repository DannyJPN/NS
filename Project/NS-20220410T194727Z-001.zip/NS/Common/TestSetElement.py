import numpy as np


class TestSetElement:
    def __init__(self, dictionary: dict):
        self.inputs = np.array([float(x) for x in dictionary['inputs']['value']])
