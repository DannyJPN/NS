import numpy as np


class TrainSetElement:
    def __init__(self, dictionary: dict):
        self.inputs = np.array([float(x) for x in dictionary['inputs']['value']])
        self.output = float(dictionary['output']) if 'output' in dictionary else np.array([float(x) for x in dictionary['outputs']['value']])
