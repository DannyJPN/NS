class InputDescription:
    def __init__(self, dictionary: dict):
        self.name = dictionary['name']
        self.minimum = float(dictionary['minimum'])
        self.maximum = float(dictionary['maximum'])
