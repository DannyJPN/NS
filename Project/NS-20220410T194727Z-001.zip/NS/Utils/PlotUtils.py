from typing import Callable

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import animation
from numpy import ndarray
import matplotlib.patches as mpatches

from Utils import Utils


class PlotUtils:
    @staticmethod
    def line_function(x, slope: float, intercept: float):
        return slope * x + intercept

    @staticmethod
    def calc_line(params: list) -> tuple:
        w0, w1, w2 = params
        slope = -(w0 / w2) / (w0 / w1)
        intercept = -w0 / w2
        return slope, intercept

    @staticmethod
    def plot_perceptron_result(train_set: list, test_set: list, train_history: list, input_descriptions: list,
                               name: str, prediction: list, time_step: float = 0.01, plot_train: bool = False):
        fig, ax = plt.subplots()
        x = np.linspace(-50, 50, 1000)
        initial_state = train_history[0]
        slope, intercept = PlotUtils.calc_line(initial_state)
        line, = ax.plot(x, PlotUtils.line_function(x, slope, intercept))

        for i, test_element in enumerate(test_set):
            point = test_element.inputs
            if prediction[i] == 0:
                color = "blue"
            elif prediction[i] == 1:
                color = "red"
            else:
                color = "blue"
            plt.scatter(point[0], point[1], c=color)

        if plot_train:
            for i, train_element in enumerate(train_set):
                point = train_element.inputs
                output = train_element.output
                if output == 0:
                    color = "black"
                elif output == 1:
                    color = "green"
                else:
                    color = "black"
                plt.scatter(point[0], point[1], c=color)

        ax.set_title(name)
        plt.xlim([input_descriptions[0].minimum - 1, input_descriptions[0].maximum + 1])
        plt.ylim([input_descriptions[1].minimum - 1, input_descriptions[1].maximum + 1])
        ax.set_xlabel(input_descriptions[0].name)
        ax.set_ylabel(input_descriptions[1].name)
        plt.legend(handles=[
            mpatches.Patch(color='blue', label='Test 0'),
            mpatches.Patch(color='red', label='Test 1'),
            mpatches.Patch(color='black', label='Train 0'),
            mpatches.Patch(color='green', label='Train 1'),
        ])

        def animate(i):
            # line.set_ydata(np.sin(x + i / 50))
            if i >= len(train_history):
                ani.event_source.stop()
                return line,
            next_state = train_history[i]
            slope, intercept = PlotUtils.calc_line(next_state)
            line.set_ydata(PlotUtils.line_function(x, slope, intercept))
            return line,

        ani = animation.FuncAnimation(fig, animate, interval=time_step * 1000, blit=True, repeat=False)

        plt.show()

    @staticmethod
    def plot_xor_result(points: list, limits: list, prediction: list):
        plt.title("Prediction")
        plt.grid()
        color = "blue"
        x, y = zip(*points)
        plt.scatter(x, y, c=prediction)
        plt.xlim([limits[0], limits[1]])
        plt.ylim([limits[0], limits[1]])
        plt.show()

    @staticmethod
    def plot_matrix(matrix: ndarray, title):
        fig, ax = plt.subplots()
        ax.matshow(matrix, cmap="binary")
        ax.set_title(title)
        plt.show()
