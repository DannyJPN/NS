import xmltodict

from Backpropagation.Backpropagation import Backpropagation
from Backpropagation.BackpropagationNeuronNet import BackpropagationNeuronNet
from Common.InputDescription import InputDescription
from Common.TestSetElement import TestSetElement
from Common.TrainSetElement import TrainSetElement


def parse_file(file_name: str) -> tuple:
    with open(f'./Backpropagation/input/{file_name}') as file:
        xml = xmltodict.parse(file.read())
        input_descriptions = [InputDescription(x) for x in
                              xml['backpropagationNeuronNet']['inputDescriptions']['inputDescription']]
        test_set = [TestSetElement(x) for x in xml['backpropagationNeuronNet']['testSet']['testSetElement']]
        train_set = [TrainSetElement(x) for x in xml['backpropagationNeuronNet']['trainSet']['trainSetElement']]
        backpropagation_neuron_net = BackpropagationNeuronNet(xml['backpropagationNeuronNet'])
        return input_descriptions, test_set, train_set, backpropagation_neuron_net


# input_descriptions, test_set, train_set, backpropagation_neuron_net = parse_file('lekar.xml')
input_descriptions, test_set, train_set, backpropagation_neuron_net = parse_file('pocasi.xml')
backpropagation = Backpropagation(input_descriptions, test_set, train_set, backpropagation_neuron_net)
backpropagation.train()
print()
backpropagation.test()