import xmltodict

from Common.InputDescription import InputDescription
from Perceptron.Perceptron import Perceptron
from Common.TestSetElement import TestSetElement
from Common.TrainSetElement import TrainSetElement
from Utils.PlotUtils import PlotUtils


def parse_file(file_name: str) -> tuple:
    with open(f'./Perceptron/input/{file_name}') as file:
        xml = xmltodict.parse(file.read())
        input_descriptions = [InputDescription(x) for x in xml['perceptronTask']['perceptron']['inputDescriptions']]
        weights = [float(x) for x in xml['perceptronTask']['perceptron']['weights']['weight']]
        test_set = [TestSetElement(x) for x in xml['perceptronTask']['TestSet']['element']]
        train_set = [TrainSetElement(x) for x in xml['perceptronTask']['TrainSet']['element']]
        learning_rate = float(xml['perceptronTask']['perceptron']['lerningRate'])
        name = xml['perceptronTask']['perceptron']['name']
        return input_descriptions, learning_rate, name, weights, test_set, train_set


input_descriptions, learning_rate, name, weights, test_set, train_set = parse_file('t2r.xml')
perceptron = Perceptron(input_descriptions, learning_rate, name, weights, test_set, train_set)
perceptron.train()
result = perceptron.test()
print(f'Dimension count: {perceptron.dimension}')
print(perceptron.train_history)
print(f'Final weights: {perceptron.weights}')
print(f'Bias: {perceptron.bias}')
if perceptron.dimension == 2:
    PlotUtils.plot_perceptron_result(train_set, test_set, perceptron.train_history,
                                     input_descriptions, name, result, 0.025, True)
