from random import random

import numpy as np

from Backpropagation.BackpropagationNeuron import BackpropagationNeuron
from Backpropagation.BackpropagationNeuronNet import BackpropagationNeuronNet
from Common.TestSetElement import TestSetElement
from Common.TrainSetElement import TrainSetElement


class Backpropagation:
    def __init__(self, input_descriptions: list, test_set: list, train_set: list,
                 backpropagation_neuron_net: BackpropagationNeuronNet):
        self.input_descriptions = input_descriptions
        self.test_set = test_set
        self.train_set = train_set
        self.backpropagation_neuron_net = backpropagation_neuron_net
        self.network = self.init_network()

    def init_network(self) -> list:
        input_size = self.backpropagation_neuron_net.inputs_count
        layers = []

        for neuron_count in self.backpropagation_neuron_net.neuron_in_layers_count:
            layer = [BackpropagationNeuron(np.array([random() for _ in range(input_size + 1)])) for _ in
                     range(neuron_count)]
            layers.append(layer)
            input_size = neuron_count

        return layers

    def forward_propagation(self, train_element: TrainSetElement) -> np.array:
        outputs = []
        inputs = train_element.inputs
        for layer in self.network:
            new_inputs = []
            for neuron in layer:
                bias = neuron.weights[-1]
                activation = np.dot(neuron.weights[:-1], inputs) + bias
                neuron.output = self.sigmoid(activation)
                new_inputs.append(neuron.output)
            inputs = new_inputs
            outputs.append(np.array(inputs))
        return outputs

    def backward_propagation(self, outputs: list, expected: np.ndarray):
        layer_index = len(self.network) - 1

        for layer, output in zip(reversed(self.network), reversed(outputs)):
            errors = []

            if layer_index != len(self.network) - 1:
                for neuron_current_index, neuron_current in enumerate(layer):
                    error = 0.0
                    for neuron_next in self.network[layer_index + 1]:
                        error += neuron_next.weights[neuron_current_index] * neuron_next.delta
                    errors.append(error)
                errors = np.array(errors)

            # output layer
            else:
                errors = output - expected

            # update delta
            deltas = errors * self.sigmoid_derivative(output)
            for i, neuron in enumerate(layer):
                neuron.delta = deltas[i]

            layer_index -= 1

    def update_weights(self, train_element: TrainSetElement):
        for layer_index, layer in enumerate(self.network):
            # input layer
            inputs = train_element.inputs

            # hidden layers
            if layer_index != 0:
                previous_layer = self.network[layer_index - 1]
                inputs = np.array([neuron.output for neuron in previous_layer])

            for neuron in layer:
                new_weights = inputs * neuron.delta * self.backpropagation_neuron_net.learning_rate
                bias = neuron.delta * self.backpropagation_neuron_net.learning_rate
                neuron.weights = np.append(new_weights, bias)

    def sigmoid(self, activation):
        return 1.0 / (1.0 + np.exp(-activation))

    def sigmoid_derivative(self, x):
        return x * (1 - x)

    def train(self, epoch_count: int = 100):
        for epoch in range(epoch_count):
            sum_error = 0
            for train_element in self.train_set:
                outputs = self.forward_propagation(train_element)

                output_layer = outputs[-1]
                expected = train_element.output
                error = 0.5 * ((output_layer - expected) ** 2)
                sum_error += np.sum(error)

                self.backward_propagation(outputs, expected)
                self.update_weights(train_element)

            print(f'epoch: #{epoch}, sum error: {sum_error}')

    def test(self):
        for test_element in self.test_set:
            output = self.predict(test_element)
            print(f'{test_element.inputs}: {output}')

    def predict(self, test: TestSetElement):
        return self.forward_propagation(test)[-1]
