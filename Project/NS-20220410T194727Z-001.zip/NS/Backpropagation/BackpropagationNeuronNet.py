class BackpropagationNeuronNet:
    def __init__(self, dictionary: dict):
        self.inputs_count = int(dictionary['inputsCount'])
        self.last_step_influence_learning_rate = float(dictionary['lastStepInfluenceLearningRate'])
        self.layers_count = float(dictionary['layersCount'])
        self.learning_rate = float(dictionary['learningRate'])
        self.neuron_in_layers_count = [int(x) for x in dictionary['neuronInLayersCount']['neuronInLayerCount']]
        self.output_descriptions = [x for x in dictionary['outputDescriptions']['outputDescription']]