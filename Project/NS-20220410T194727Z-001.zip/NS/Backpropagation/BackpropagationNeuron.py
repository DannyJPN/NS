class BackpropagationNeuron:
    def __init__(self, weights: list):
        self.weights = weights