package vsb.stud.ns.backpropagation.model;

import vsb.stud.ns.backpropagation.model.neuronio.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class BackpropagationNeuron {

    protected double inputValueSum; // aka net and Z
    protected double outputValue; // aka out and A

    protected List<BackpropagationNeuronInput> inputs = new ArrayList<>();
    protected List<BackpropagationNeuronOutput> outputs = new ArrayList<>();

    public BackpropagationNeuron() {
        connectInput(new BackpropagationBiasInput());
    }

    public static void connectNeurons(BackpropagationNeuron downstreamNeuron, BackpropagationNeuron upstreamNeuron) {
        BackpropagationNeuronWeightedInput connection = new BackpropagationNeuronWeightedInput();
        downstreamNeuron.connectOutput(connection);
        upstreamNeuron.connectInput(connection);
    }

    public static void connectBatchNeurons(BackpropagationNeuron downstreamNeuron, BackpropagationNeuron upstreamNeuron) {
        BackpropagationNeuronWeightedInputBatch connection = new BackpropagationNeuronWeightedInputBatch();
        downstreamNeuron.connectOutput(connection);
        upstreamNeuron.connectInput(connection);
    }

    public static void connectInput(NetworkInput input, BackpropagationNeuron upstreamNeuron) {
        BackpropagationNeuronWeightedInput connection = new BackpropagationNeuronWeightedInput();
        input.connectOutput(connection);
        upstreamNeuron.connectInput(connection);
    }


    public void connectOutput(BackpropagationNeuronOutput output) {
        outputs.add(output);
    }

    public void connectInput(BackpropagationNeuronInput input) {
        inputs.add(input);
    }

    public void calculateOutput() {
        inputValueSum = 0.0;
        for (BackpropagationNeuronInput input : inputs) {
            inputValueSum += input.getWeightedInputValue();
        }

        //logical function as activation function
        outputValue = 1 / (1+ Math.exp(-inputValueSum));

        for (BackpropagationNeuronOutput output : outputs) {
            output.propagateNeuronOutputUpstream(outputValue);
        }
    }

    public void calculateError() {
        double outputErrorSum = 0.0;
        for (BackpropagationNeuronOutput output : outputs) {
            outputErrorSum += output.getUpstreamWeightedNeuronError();
        }

        double neuronError = outputErrorSum * (outputValue * (1 - outputValue));

        for (BackpropagationNeuronInput input : inputs) {
            input.propagateNeuronErrorDownstream(neuronError);
        }
    }

    public void updateWeighs() {
        for (BackpropagationNeuronInput input : inputs) {
            input.updateWeight();
        }
    }
}
