package vsb.stud.ns.backpropagation.model.neuronio;

import vsb.stud.ns.backpropagation.model.BackpropagationConfiguration;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class BackpropagationNeuronWeightedInputBatch implements BackpropagationNeuronInput, BackpropagationNeuronOutput {

    protected double weight;
    protected double batchWeight;

    protected Double downstreamNeuronValue;
    protected Double upstreamNeuronError; // E/out * out/net

    public BackpropagationNeuronWeightedInputBatch() {
        weight = BackpropagationConfiguration.getInstance().getRandom().nextDouble();
        batchWeight = weight;
    }

    @Override
    public synchronized double getWeightedInputValue() {
        return downstreamNeuronValue * weight;
    }

    @Override
    public synchronized void propagateNeuronOutputUpstream(double outputValue) {
        downstreamNeuronValue = outputValue;
    }

    @Override
    public synchronized void propagateNeuronErrorDownstream(double neuronError) {
        upstreamNeuronError = neuronError;
        batchWeight -= BackpropagationConfiguration.getInstance().getLearningRate() * upstreamNeuronError * downstreamNeuronValue;
    }

    @Override
    public synchronized double getUpstreamWeightedNeuronError() {
        return upstreamNeuronError * weight;
    }

    @Override
    public synchronized void updateWeight() {
        weight = batchWeight;
    }
}
