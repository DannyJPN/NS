package vsb.stud.ns.backpropagation.model.neuronio;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public interface BackpropagationNeuronOutput {

    public void propagateNeuronOutputUpstream(double outputValue);
    public double getUpstreamWeightedNeuronError();
}
