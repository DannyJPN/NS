package vsb.stud.ns.backpropagation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vsb.stud.ns.backpropagation.model.BackpropagationConfiguration;
import vsb.stud.ns.backpropagation.model.jaxb.BackpropagationNeuronNet;

import javax.xml.bind.JAXBException;
import java.io.File;
import java.util.Collections;

/**
 * Hello world!
 */
public class NsBackpropagationBatch {
    private static final Logger log = LoggerFactory.getLogger(NsBackpropagationBatch.class);

    public static void main(String[] args) throws JAXBException {
        //String sourceFilePath = "src/main/resources/signs.xml";
        String sourceFilePath = "src/main/resources/signs2.xml";
        //String sourceFilePath = "src/main/resources/lekar.xml";
        if (args.length != 0) {
            sourceFilePath = args[0];
        }

        BackpropagationNeuronNet netDescription = BackpropagationNeuronNet.readFromXml(new File(sourceFilePath));

        BackpropagationNeuralNetworkBatchStudy network = new BackpropagationNeuralNetworkBatchStudy(netDescription);
        BackpropagationConfiguration.getInstance().setLearningRate(netDescription.getLearningRate());

        double lastIterationError = 0.0;
        for (int i= 0; i < 300; i++) {
            double iterationError = 0.0;
            Collections.shuffle(netDescription.getTrainingSet());
            for (vsb.stud.ns.backpropagation.model.jaxb.TrainSetElement trainSetElement : netDescription.getTrainingSet()) {
                double error = network.study(trainSetElement.getInputs(), trainSetElement.getOutput());
                iterationError+= error;
            }

            network.studyUpdate();

            double errorDelta = lastIterationError-iterationError;
            if(i != 0) {
                //log.info("{} - Iteration error: {}, delta: {}", i,  iterationError, errorDelta);
                System.out.println( i +"\t"+  iterationError/2/network.outputs.size()/netDescription.getTrainingSet().size()+"\t"+  errorDelta/2/network.outputs.size()/netDescription.getTrainingSet().size() );
                /*if(errorDelta < 0.001) {
                    break;
                }*/
            }
            lastIterationError = iterationError;

        }

        int i = 10;
    }
}
