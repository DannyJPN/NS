package vsb.stud.ns.backpropagation.connector;

import java.util.HashMap;

public interface DriverInterface {

	public HashMap<String, Float> drive(HashMap<String, Float> values);
}
