package vsb.stud.ns.backpropagation.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class BackpropagationConfiguration {

    private static final BackpropagationConfiguration instance = new BackpropagationConfiguration();

    private double learningRate = 0.3;

    private Random random = new Random();

    private BackpropagationConfiguration() {
    }

    public static BackpropagationConfiguration getInstance() {
        return instance;
    }

    public double getLearningRate() {
        return learningRate;
    }

    public void setLearningRate(double learningRate) {
        this.learningRate = learningRate;
    }



    public Random getRandom() {
        return random;
    }
}