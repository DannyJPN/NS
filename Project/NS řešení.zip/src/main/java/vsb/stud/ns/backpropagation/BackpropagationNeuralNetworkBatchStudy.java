package vsb.stud.ns.backpropagation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vsb.stud.ns.backpropagation.model.BackpropagationNeuron;
import vsb.stud.ns.backpropagation.model.jaxb.BackpropagationNeuronNet;
import vsb.stud.ns.backpropagation.model.jaxb.InputDescription;
import vsb.stud.ns.backpropagation.model.neuronio.BackpropagationNeuronWeightedInputBatch;
import vsb.stud.ns.backpropagation.model.neuronio.NetworkInput;
import vsb.stud.ns.backpropagation.model.neuronio.NetworkOutput;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class BackpropagationNeuralNetworkBatchStudy {
    private static final Logger log = LoggerFactory.getLogger(BackpropagationNeuralNetworkBatchStudy.class);

    protected List<NetworkInput> inputs = new ArrayList<>();
    protected List<NetworkOutput> outputs = new ArrayList<>();

    protected List<List<BackpropagationNeuron>> network = new ArrayList<>();

    public BackpropagationNeuralNetworkBatchStudy(BackpropagationNeuronNet netDescription) {
        List<BackpropagationNeuron> lastLayerNeurons = new ArrayList<>();
        for (String outputDescription: netDescription.getOutputDescriptions()) {
            NetworkOutput output = new NetworkOutput(outputDescription);
            BackpropagationNeuron neuron = new BackpropagationNeuron();
            neuron.connectOutput(output);
            outputs.add(output);
            lastLayerNeurons.add(neuron);
        }
        network.add(lastLayerNeurons);

        List<BackpropagationNeuron> currentLayerNeurons = new ArrayList<>();
        for (int layerIndex = netDescription.getNeuronInLayersCount().length-2; layerIndex >= 0; layerIndex--) {
            int noNeuronsInLayer = netDescription.getNeuronInLayersCount()[layerIndex];
            for (int neuronInLayerIndex = 0; neuronInLayerIndex < noNeuronsInLayer; neuronInLayerIndex++) {
                BackpropagationNeuron neuron = new BackpropagationNeuron();
                for (BackpropagationNeuron lastLayerNeuron : lastLayerNeurons) {
                    BackpropagationNeuron.connectBatchNeurons(neuron, lastLayerNeuron);
                }
                currentLayerNeurons.add(neuron);
            }
            network.add(0, currentLayerNeurons);
            lastLayerNeurons = currentLayerNeurons;
            currentLayerNeurons = new ArrayList<>();
        }

        for (InputDescription inputDescription : netDescription.getInputDescriptions()) {
            NetworkInput input = new NetworkInput(inputDescription.getName(), inputDescription.getMinimum(), inputDescription.getMaximum());
            for (BackpropagationNeuron lastLayerNeuron : lastLayerNeurons) {
                BackpropagationNeuron.connectInput(input, lastLayerNeuron);
            }
            inputs.add(input);
        }
    }


    public double study(double[] input, double[] expectedOutput){

        double[] output = execute(input);

        // set expected response and calculate total error
        double totalError = 0.0;
        for (int i = 0; i < expectedOutput.length; i++) {
            outputs.get(i).setExpectedOutputValue(expectedOutput[i]);
            totalError+= Math.abs(outputs.get(i).getUpstreamWeightedNeuronError());
        }

        // propagate error
        for (int i = network.size() - 1; i >= 0; i--) {
            for (BackpropagationNeuron neuron : network.get(i)) {
                neuron.calculateError();
            }
        }

        //log.debug("study input: {}, output: {}, expected output: {} error: {}", input, output, expectedOutput, totalError);
        return totalError;
    }

    public void studyUpdate() {
        // updateWeighs weighs - could be called internally when error is propagated downstream
        for (List<BackpropagationNeuron> networkLayer : network) {
            for (BackpropagationNeuron neuron : networkLayer) {
                neuron.updateWeighs();
            }
        }
    }


    public double[] execute(double[] input) {
        // set inputs
        for (int i = 0; i < input.length; i++) {
            inputs.get(i).setInputValue(input[i]);
        }

        // calculate output
        for (List<BackpropagationNeuron> networkLayer : network) {
            for (BackpropagationNeuron neuron : networkLayer) {
                neuron.calculateOutput();
            }
        }

        // retrieve output
        double[] result = new double[outputs.size()];
        for (int i = 0; i < outputs.size(); i++) {
            result[i] = outputs.get(i).getOutputValue();
        }

        return result;
    }
}
