package vsb.stud.ns.hebb;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import vsb.stud.ns.hebb.model.InputDescription;
import vsb.stud.ns.hebb.model.PerceptronTask;
import vsb.stud.ns.hebb.model.TestSetElement;
import vsb.stud.ns.hebb.model.TrainSetElement;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;

public class HebbPerceptronUiController implements Initializable {

    @FXML
    private Button btNextStudySample;

    @FXML
    private LineChart<Number, Number> lchGraph;

    @FXML
    private Label lbWeights;

    private PerceptronTask task;
    private HebbPerceptron perceptron;

    public HebbPerceptronUiController(HebbPerceptron perceptron, PerceptronTask task) {
        this.perceptron = perceptron;
        this.task = task;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        displayPerceptronWeights();

        btNextStudySample.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for (TrainSetElement trainSetElement : HebbPerceptronUiController.this.task.getTrainSet()) {
                    perceptron.train(trainSetElement.getInputs(), trainSetElement.getIntOutput() != 0 ? 1 : -1);
                }

                lchGraph.getData().clear();
                displayPerceptronWeights();
                displayTestSet();
                displayTrainSet();
            }
        });

    }

    private void displayTestSet() {
        if (perceptron.getInputWeights().length == 2) {

            XYChart.Series testSet = new XYChart.Series();
            testSet.setName("Test set");
            for (TestSetElement testSetElement : task.getTestSet()) {
                testSet.getData().add(new XYChart.Data(testSetElement.getInputs()[0], testSetElement.getInputs()[1]));
            }
            lchGraph.getData().add(testSet);
        }
    }

    private void displayTrainSet() {
        if (perceptron.getInputWeights().length == 2) {

            XYChart.Series correctSet = new XYChart.Series();
            correctSet.setName("Train set - correct");
            XYChart.Series incorrrectSet = new XYChart.Series();
            incorrrectSet.setName("Train set - incorrect");
            for (TrainSetElement trainSetElement : task.getTrainSet()) {
                int result = perceptron.executed(trainSetElement.getInputs());
                if (result == trainSetElement.getOutput()) {
                    correctSet.getData().add(new XYChart.Data(trainSetElement.getInputs()[0], trainSetElement.getInputs()[1]));
                } else {
                    incorrrectSet.getData().add(new XYChart.Data(trainSetElement.getInputs()[0], trainSetElement.getInputs()[1]));
                }
            }
            lchGraph.getData().addAll(correctSet, incorrrectSet);
        }
    }

    public void displayPerceptronWeights() {
        InputDescription[] perceptronInputDescriptions = perceptron.getInputDescriptions();
        double[] perceptronWeights = perceptron.getInputWeights();
        double perceptronBias = perceptron.getBias();

        if (perceptron.getInputWeights().length == 2) {
            double interceptNormalized = -perceptronBias / perceptronWeights[1];
            double slopeNormalized = interceptNormalized / (perceptronBias / perceptronWeights[0]);

            double intercept = (interceptNormalized * (perceptron.getInputDescriptions()[1].getMaximum() - perceptron.getInputDescriptions()[1].getMinimum())) + perceptron.getInputDescriptions()[1].getMinimum();
            double slope = slopeNormalized;

            XYChart.Series perceptronWeightsChart = new XYChart.Series();
            perceptronWeightsChart.setName("Perceptron weights");
            double wChX1 = perceptronInputDescriptions[0].getMinimum();
            double wChY1 = intercept + wChX1 * slope;
            double wChX2 = perceptronInputDescriptions[0].getMaximum();
            double wChY2 = intercept + wChX2 * slope;

            perceptronWeightsChart.getData().add(new XYChart.Data(wChX1, wChY1));
            perceptronWeightsChart.getData().add(new XYChart.Data(wChX2, wChY2));

            lchGraph.getData().add(perceptronWeightsChart);
        }

        StringBuilder sb = new StringBuilder();
        DecimalFormat df = new DecimalFormat("#.###");
        sb.append("Bias: ").append(df.format(perceptronBias));
        for (int i = 0; i < perceptronWeights.length; i++) {
            sb.append(", w").append(i).append(": ").append(df.format(perceptronWeights[i]));
        }
        lbWeights.setText(sb.toString());
    }
}
