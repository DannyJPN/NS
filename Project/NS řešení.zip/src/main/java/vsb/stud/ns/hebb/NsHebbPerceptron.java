package vsb.stud.ns.hebb;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vsb.stud.ns.hebb.model.TrainSetElement;
import vsb.stud.ns.hebb.model.PerceptronTask;

import javax.xml.bind.JAXBException;
import java.io.File;
import java.net.ServerSocket;
import java.util.Arrays;

/**
 * Hello world!
 */
public class NsHebbPerceptron extends Application {

    private static final Logger log = LoggerFactory.getLogger(NsHebbPerceptron.class);
    private static String sourceFilePath = "src/main/resources/obdelnik_rozsah.xml";

    @Override
    public void start(Stage primaryStage) throws Exception{

        PerceptronTask task = PerceptronTask.loadFromXML(new File(sourceFilePath));

        HebbPerceptron perceptron = new HebbPerceptron(task.getPerceptron().getLerningRate(),
                task.getPerceptron().getWeights()[0],
                Arrays.copyOfRange(task.getPerceptron().getWeights(), 1, task.getPerceptron().getWeights().length),
                task.getPerceptron().getInputDescriptions());



        HebbPerceptronUiController controller = new HebbPerceptronUiController(perceptron, task);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/HebbUi.fxml"));
        loader.setController(controller);
        Parent root = loader.load();


        primaryStage.setTitle("NS - KRE0297 - Hebb perceptron");
        Scene scene = new Scene(root, 1024, 800);
        scene.getStylesheets().add(getClass().getResource("/HebbUiStyle.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) throws JAXBException {
        if (args.length != 0) {
            sourceFilePath = args[0];
        }

        /*
        PerceptronTask task = PerceptronTask.loadFromXML(new File(sourceFilePath));

        HebbPerceptron perceptron = new HebbPerceptron(task.getPerceptron().getLerningRate(),
                task.getPerceptron().getInputWeights()[0],
                Arrays.copyOfRange(task.getPerceptron().getInputWeights(), 1, task.getPerceptron().getInputWeights().length));

        int learningStep = 1;
        for (; learningStep < 100; learningStep++) {

            for (TrainSetElement trainSetElement : task.getTrainSet()) {
                perceptron.train(trainSetElement.getInputs(), trainSetElement.getIntOutput() != 0 ? 1: -1);
            }

            log.info("New learning iteration {}",learningStep);
            int correctMatches = 0;
            for (TrainSetElement trainSetElement : task.getTrainSet()) {
                int output = perceptron.executed(trainSetElement.getInputs());
                int expectedOutput = trainSetElement.getIntOutput();
                log.info("Element: {} ({}) is: {}", trainSetElement.getInputs(), expectedOutput, output);
                if(output == expectedOutput) {
                    correctMatches++;
                }
            }
            if(correctMatches == task.getTrainSet().size()) {
                break;
            }
        }



*/
        launch(args);
    }
}
