package vsb.stud.ns.backpropagation.model.neuronio;

import vsb.stud.ns.backpropagation.model.BackpropagationConfiguration;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class NetworkInput {

    private String name;

    private double valueRangeMin;
    private double valueRangeMax;

    private List<BackpropagationNeuronOutput> outputs = new ArrayList<>();

    public NetworkInput(String name, double valueRangeMin, double valueRangeMax) {
        this.name = name;
        this.valueRangeMin = valueRangeMin;
        this.valueRangeMax = valueRangeMax;
    }


    public void setInputValue(double value) {

        double normalizedValue = (value - valueRangeMin) / (valueRangeMax - valueRangeMin);

        for (BackpropagationNeuronOutput output : outputs) {
            output.propagateNeuronOutputUpstream(normalizedValue);
        }
    }

    public void connectOutput(BackpropagationNeuronWeightedInput output) {
        outputs.add(output);
    }
}
