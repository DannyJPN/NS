package vsb.stud.ns.backpropagation.model.neuronio;

import vsb.stud.ns.backpropagation.model.BackpropagationConfiguration;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class BackpropagationNeuronWeightedInput implements BackpropagationNeuronInput, BackpropagationNeuronOutput {

    protected double weight;

    protected Double downstreamNeuronValue;
    protected Double upstreamNeuronError; // E/out * out/net

    public BackpropagationNeuronWeightedInput() {
        weight = BackpropagationConfiguration.getInstance().getRandom().nextDouble();
    }

    @Override
    public synchronized double getWeightedInputValue() {
        return downstreamNeuronValue * weight;
    }

    @Override
    public synchronized void propagateNeuronOutputUpstream(double outputValue) {
        downstreamNeuronValue = outputValue;
    }

    @Override
    public synchronized void propagateNeuronErrorDownstream(double neuronError) {
        upstreamNeuronError = neuronError;
    }

    @Override
    public synchronized double getUpstreamWeightedNeuronError() {
        return upstreamNeuronError * weight;
    }

    @Override
    public synchronized void updateWeight() {
        weight -= BackpropagationConfiguration.getInstance().getLearningRate() * upstreamNeuronError * downstreamNeuronValue;
    }
}
