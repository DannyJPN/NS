package vsb.stud.ns.backpropagation.model.neuronio;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public interface BackpropagationNeuronInput {
    public double getWeightedInputValue();
    public void propagateNeuronErrorDownstream(double neuronError);

    public void updateWeight();

}
