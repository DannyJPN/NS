package vsb.stud.ns.backpropagation.model.neuronio;

import vsb.stud.ns.backpropagation.model.BackpropagationConfiguration;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class BackpropagationBiasInput implements BackpropagationNeuronInput {

    protected double biasWeight;

    protected Double upstreamNeuronError; // E/out * out/net

    public BackpropagationBiasInput() {
        biasWeight = BackpropagationConfiguration.getInstance().getRandom().nextDouble();
    }

    @Override
    public double getWeightedInputValue() {
        return biasWeight;
    }

    @Override
    public void propagateNeuronErrorDownstream(double neuronError) {
        upstreamNeuronError = neuronError;
    }

    @Override
    public void updateWeight() {
        biasWeight -= BackpropagationConfiguration.getInstance().getLearningRate() * upstreamNeuronError;
    }
}
