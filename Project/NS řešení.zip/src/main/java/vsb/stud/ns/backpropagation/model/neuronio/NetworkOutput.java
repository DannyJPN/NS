package vsb.stud.ns.backpropagation.model.neuronio;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class NetworkOutput implements BackpropagationNeuronOutput {

    protected String name;

    protected double outputValue;
    protected double expectedOutputValue;

    public NetworkOutput(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public double getOutputValue() {
        return outputValue;
    }

    public double getExpectedOutputValue() {
        return expectedOutputValue;
    }

    public void setExpectedOutputValue(double expectedOutputValue) {
        this.expectedOutputValue = expectedOutputValue;
    }

    @Override
    public void propagateNeuronOutputUpstream(double outputValue) {
        this.outputValue = outputValue;
    }

    @Override
    public double getUpstreamWeightedNeuronError() {
        return 2 * (outputValue - expectedOutputValue);
    }
}
