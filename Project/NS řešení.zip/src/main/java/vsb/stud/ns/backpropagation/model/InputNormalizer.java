package vsb.stud.ns.backpropagation.model;

import vsb.stud.ns.backpropagation.model.jaxb.InputDescription;

import java.util.List;

/**
 * Created by fg6pvq on 9.4.2020.
 */
public class InputNormalizer {

    List<InputDescription> inputDescriptions;

    public InputNormalizer(List<InputDescription> inputDescriptions) {
        this.inputDescriptions = inputDescriptions;
    }

    public double[] normalizeInput(double[] input) {
        if(inputDescriptions.size() != input.length) {
            throw new IllegalArgumentException("Input descriptor size don't match input size");
        }

        double[] result = new double[input.length];
        for (int i = 0; i < inputDescriptions.size(); i++) {
            InputDescription description = inputDescriptions.get(i);
            result[i] = (input[i] - description.getMinimum()) / (description.getMaximum() - description.getMinimum());
        }

        return result;
    }

}
