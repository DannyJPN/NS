package vsb.stud.ns.hebb;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vsb.stud.ns.hebb.model.InputDescription;

import java.util.Arrays;

/**
 * Created by fg6pvq on 5.4.2020.
 */
public class HebbPerceptron {

    private static final Logger log = LoggerFactory.getLogger(HebbPerceptron.class);

    private double learingRate;
    private double bias;
    private double[] inputWeights; //first is for bias
    private InputDescription[] inputDescriptions;

    public HebbPerceptron(double learingRate, double initialBias, double[] initialInputWeights, InputDescription[] inputDescriptions) {
        this.learingRate = learingRate;
        this.bias = initialBias;
        this.inputWeights = Arrays.copyOf(initialInputWeights, initialInputWeights.length);
        this.inputDescriptions = inputDescriptions;
    }

    protected double[] normalizeInput(double[] input) {
        double[] result = new double[input.length];
        for (int i = 0; i < input.length; i++) {
            result[i] = (input[i] - inputDescriptions[i].getMinimum()) / (inputDescriptions[i].getMaximum() - inputDescriptions[i].getMinimum());
        }
        return result;
    }

    public void train(double[] input, int expectedOutput){
        if(input == null || input.length != inputWeights.length) {
            throw new IllegalArgumentException("Input size: "+ input.length +" don't match with perceptron expected input size: " + inputWeights.length);
        }
        double[] normalizedInputs = normalizeInput(input);
        double[] newInputWeights = new double[inputWeights.length];
        double newBias = bias + learingRate * expectedOutput; // bias
        for (int i = 0; i < inputWeights.length; i++) {
            newInputWeights[i] = inputWeights[i] + learingRate * normalizedInputs[i] * expectedOutput;
        }

        bias = newBias;
        inputWeights = newInputWeights;
        log.info("Perceptron trained with: {} ({}) - new weights: {} and bias: {}", input, expectedOutput, inputWeights, bias);
    }

    public int executed(double[] input) {
        if(input == null || input.length != inputWeights.length) {
            throw new IllegalArgumentException("Input size: "+ input.length +" don't match with perceptron expected input size: " + inputWeights.length);
        }

        double[] normalizedInputs = normalizeInput(input);
        double sum = bias;
        for (int i = 0; i < normalizedInputs.length; i++) {
            sum += normalizedInputs[i] * inputWeights[i];
        }

        log.info("Result for: {} is {}", input, sum);
        return sum > 0 ? 1 : 0;
    }


    public double[] getInputWeights() {
        return inputWeights;
    }

    public double getBias() {
        return bias;
    }

    public InputDescription[] getInputDescriptions() {
        return inputDescriptions;
    }
}
