package vsb.stud.ns;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by fg6pvq on 3.5.2020.
 */
public class ImageToNetInput {

    public static void main(String[] args) throws IOException {
        String result = "";

        BufferedImage image = ImageIO.read(new File("src/main/resources/plus.png"));
        List<Integer> imageInputInts = imageToNetInput(image);
        result += convertToXml(imageInputInts, 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.8), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.7), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.6), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.5), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.4), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.4), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 1,0,0,0);


        image = ImageIO.read(new File("src/main/resources/minus.png"));
        imageInputInts = imageToNetInput(image);
        result += convertToXml(imageInputInts, 0, 1, 0, 0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.8), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.7), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.6), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.5), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.4), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.4), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,1,0,0);

        image = ImageIO.read(new File("src/main/resources/multiply.png"));
        imageInputInts = imageToNetInput(image);
        result += convertToXml(imageInputInts, 0, 0, 1, 0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.8), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.7), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.6), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.5), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.4), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.4), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,1,0);

        image = ImageIO.read(new File("src/main/resources/divide.png"));
        imageInputInts = imageToNetInput(image);
        result += convertToXml(imageInputInts, 0, 0, 0, 1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.8), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.7), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.6), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.5), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.4), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.4), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.3), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);
        result += convertToXml(addNoise(imageInputInts, 255, 0.2), 0,0,0,1);

        System.out.println(result);

        System.out.println(generateInputDesc(image));

    }

    private static List<Integer> addNoise(List<Integer> imageInputInts, int target, double delta) {
        List<Integer> result = new ArrayList<>(imageInputInts.size());
        for (Integer imageInputInt : imageInputInts) {
            if(imageInputInt == target) {
                result.add((int)Math.round(imageInputInt * (1 - (Math.random() * delta))));
            } else {
                result.add(imageInputInt);
            }
        }
        return result;
    }

    private static String generateInputDesc(BufferedImage image) {
        StringBuilder sb = new StringBuilder();
        sb.append("<inputDescriptions>");
        int inpCount = image.getHeight() * image.getWidth();
        for (int i = 0; i < inpCount; i++) {
            sb.append("<inputDescription><maximum>255.0</maximum><minimum>0.0</minimum><name>").append(i).append("</name></inputDescription>");
        }
        sb.append("</inputDescriptions>");
        sb.append("<inputsCount>").append(inpCount).append("</inputsCount>");
        return sb.toString();
    }

    private static String convertToXml(List<Integer> imageInputInts, Integer... imageOutputInts) {
        StringBuilder sb = new StringBuilder();

        sb.append("<trainSetElement><inputs>");
        for (Integer imageInputInt : imageInputInts) {
            sb.append("<value>").append(imageInputInt).append("</value>");
        }
        sb.append("</inputs><outputs>");
        for (Integer imageOutputInt : imageOutputInts) {
            sb.append("<value>").append(imageOutputInt).append("</value>");

        }
        sb.append("</outputs></trainSetElement>");
        return sb.toString();
    }

    private static List<Integer> imageToNetInput(BufferedImage image) {

        int width = image.getWidth();
        int height = image.getHeight();
        List<Integer> result = new ArrayList<>();

        for (int col = 0; col < width; col++) {
            for (int row = 0; row < height; row++) {
                result.add(image.getData().getSample(row, col, 0));
            }
        }

        return result;
    }

}

